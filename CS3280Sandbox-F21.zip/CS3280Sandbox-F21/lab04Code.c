#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#define SENTINEL 255

int subroutine(int *p)
{
    int factorial = 1;
    int i = 0;
    while(i < *p)
    {
        int sum=0;
        int j = 0;
        while(j <= i)
        {
            sum = sum + factorial;
            j++;
        }
        factorial = sum;
        i++;
    }
    *p = factorial;
    return *p;
}

int main(void)
{
    unsigned int N[6] = {0,1,5,8,10, SENTINEL};
    unsigned int NFAC[5];
    unsigned int *ptr1;
    unsigned int *ptr2;
    ptr1 = &N[0];
    ptr2 = &NFAC[0];

    while(*ptr1 != SENTINEL)
    {
        subroutine(ptr1);
        *ptr2 = *ptr1;
        *ptr1++;
        *ptr2++;
    }

}