#include <stdio.h>
#define N 5
unsigned int sum;
unsigned int i;

int main(){

    /* STEP 1 of Lab
    for(i=0;i<=N;i++)sum+=i;    
    */

   i=0;
   sum=0;
   while(i<=N){
       sum+=i;
       i++;
   }

    printf("N: %u -> sum %u , %x\n", N, sum, sum);
    
    return 0;
}