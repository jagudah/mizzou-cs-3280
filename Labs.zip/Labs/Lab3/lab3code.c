#include <stdio.h>

    unsigned int num1 = 186;
    unsigned int num2 = 248;
    unsigned int gcd;
    unsigned int remainder = 1;
    unsigned int tNum1,tNum2;

int main(){
    if(num1 < num2){
        tNum1 = num2;
        tNum2 = num1;
    }
    else{
        tNum1 = num1;
        tNum2 = num2;
    }

    while(remainder != 0){

        while(tNum1 >= tNum2){
            tNum1 -= tNum2;
            remainder = tNum1;
        }

        if(tNum1 < tNum2){
            gcd = tNum2;
            tNum1 = tNum2;
            tNum2 = remainder;
        }
    }

    printf("GCD: %u\n", gcd);

    return 0;

}