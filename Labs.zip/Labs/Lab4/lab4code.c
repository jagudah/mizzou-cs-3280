#include <stdio.h>

int GCD(unsigned int t1, unsigned int t2)
{
    unsigned int gcd;
    unsigned int remainder = 1;
    unsigned int tNum1,tNum2;

    if(t1 < t2)
    {
        tNum1 = t2;
        tNum2 = t1;
    }
    else
    {
        tNum1 = t1;
        tNum2 = t2;
    }

    while(remainder != 0)
    {

        while(tNum1 >= tNum2)
        {
            tNum1 -= tNum2;
            remainder = tNum1;
        }

        if(tNum1 < tNum2)
        {
            gcd = tNum2;
            tNum1 = tNum2;
            tNum2 = remainder;
        }
    }

    return gcd;
}

int main()
{
    unsigned int table1[] = {222,37,16,55,55,1,3,22,255};
    unsigned int table2[] = {37,222,240,5,55,15,22,3,255};
    unsigned int result[8];
    unsigned int *ptr1, *ptr2, *res;
    ptr1 = &table1[0];
    ptr2 = &table2[0];
    res = &result[0];
    unsigned int A = 0;
    unsigned int B = 0;

    while(B != 255)
    {
        A = *ptr1;
        B = *ptr2;
        *res = GCD(A, B);
        ptr1++;
        ptr2++;
        res++;
    }
    
    for(int j=0; j<8; j++)
    {
        printf("%d ", result[j]);
    }

    return 0;
}