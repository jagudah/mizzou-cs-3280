#include <stdio.h>

unsigned int dividend = 10;
unsigned int divisor = 0;
unsigned int quotient;
unsigned int remainder;
unsigned int temp1,temp2;

int main(){

    quotient = 0;
    remainder = 0;
    temp1 = dividend;
    temp2 = divisor;

    if(temp1 < temp2){
        remainder = temp1;
    }

    while(temp1 >= temp2){
        temp1 -= temp2;
        quotient++;
        remainder = temp1;

        if(temp1 == dividend){
            quotient = 255;
            remainder = 255;
            temp1 = 0;
            temp2 = 255;
        }
    }

    printf("Quotient: %u\n", quotient);
    printf("Remainder: %u\n", remainder);

    return 0;

}
main();